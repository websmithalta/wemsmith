import React from 'react';
import { Globe, PenTool, Code, BarChart3, RefreshCw, Layers } from 'lucide-react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => {
  return (
    <div className="flex flex-col bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md hover:border-blue-100 transition-all duration-300 group">
      <div className="p-4 rounded-lg bg-blue-50 text-blue-700 inline-block mb-6 group-hover:bg-blue-700 group-hover:text-white transition-all duration-300">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
      <p className="text-gray-600 flex-grow">{description}</p>
      <a
        href="#contact"
        className="mt-6 text-blue-700 font-medium inline-flex items-center group-hover:text-blue-800"
      >
        Learn more
        <svg
          className="ml-2 w-5 h-5 transition-transform duration-300 group-hover:translate-x-1"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
        </svg>
      </a>
    </div>
  );
};

const Services: React.FC = () => {
  const services = [
    {
      icon: <Globe className="w-6 h-6" />,
      title: 'Website Development',
      description: 'Custom-built, responsive websites designed to convert visitors into customers and elevate your brand online.'
    },
    {
      icon: <RefreshCw className="w-6 h-6" />,
      title: 'Website Revamp',
      description: 'Transform your outdated site into a modern, high-performing platform that aligns with current standards and trends.'
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: 'Web Applications',
      description: 'Interactive, feature-rich web applications that solve specific business problems and enhance user experience.'
    },
    {
      icon: <PenTool className="w-6 h-6" />,
      title: 'UI/UX Design',
      description: 'User-centered design that creates intuitive, engaging interfaces focused on maximizing user satisfaction.'
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: 'SEO Optimization',
      description: 'Strategic optimization to improve visibility, increase organic traffic, and boost search engine rankings.'
    },
    {
      icon: <Layers className="w-6 h-6" />,
      title: 'Content Strategy',
      description: 'Comprehensive content planning that aligns with your business goals and resonates with your target audience.'
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our Digital Services</h2>
          <p className="text-xl text-gray-600">
            We offer comprehensive digital solutions tailored to help your business grow online.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
            />
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-blue-700 hover:bg-blue-800 transition-colors duration-300 transform hover:scale-105"
          >
            Discuss Your Project
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;