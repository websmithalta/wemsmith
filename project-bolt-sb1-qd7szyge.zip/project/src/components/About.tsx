import React from 'react';
import { CheckCircle, Award, Users, Clock } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { icon: <Users className="w-6 h-6 text-blue-700" />, count: '100+', label: 'Happy Clients' },
    { icon: <Award className="w-6 h-6 text-blue-700" />, count: '10+', label: 'Years Experience' },
    { icon: <CheckCircle className="w-6 h-6 text-blue-700" />, count: '250+', label: 'Projects Completed' },
    { icon: <Clock className="w-6 h-6 text-blue-700" />, count: '24/7', label: 'Support Available' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex lg:items-center lg:gap-16">
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-700 rounded-2xl transform translate-x-4 translate-y-4"></div>
              <img
                src="https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Our team collaborating on a project"
                className="relative rounded-2xl shadow-lg w-full h-full object-cover z-10"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-50 rounded-lg shadow-xl p-6 z-20">
                <p className="text-5xl font-bold text-blue-700">5.0</p>
                <div className="flex mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className="w-5 h-5 text-yellow-500"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-sm text-gray-600 mt-1">Client Rating</p>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              We Create Digital Experiences That Get Results
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Webify is a full-service digital marketing agency specialized in crafting bespoke websites and digital strategies that drive business growth. We combine technical expertise with creative design to deliver solutions that stand out in today's competitive landscape.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              Our approach is collaborative and results-driven. We work closely with our clients to understand their unique challenges and goals, then craft tailored solutions that exceed expectations and deliver measurable ROI.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-2">{stat.icon}</div>
                  <p className="text-2xl font-bold text-gray-900">{stat.count}</p>
                  <p className="text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>

            <a
              href="#contact"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-blue-700 hover:bg-blue-800 transition-colors duration-300"
            >
              Let's Work Together
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;