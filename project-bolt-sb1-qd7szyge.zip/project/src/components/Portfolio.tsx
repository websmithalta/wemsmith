import React, { useState } from 'react';
import { ExternalLink } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
}

const Portfolio: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const projects: Project[] = [
    {
      id: 1,
      title: 'Modern E-commerce Platform',
      category: 'ecommerce',
      image: 'https://images.pexels.com/photos/6956878/pexels-photo-6956878.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'A fully responsive e-commerce platform with integrated payment systems and inventory management.'
    },
    {
      id: 2,
      title: 'Corporate Banking Portal',
      category: 'corporate',
      image: 'https://images.pexels.com/photos/3183183/pexels-photo-3183183.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Secure banking portal with custom dashboard for financial institutions.'
    },
    {
      id: 3,
      title: 'Health & Wellness App',
      category: 'health',
      image: 'https://images.pexels.com/photos/5327534/pexels-photo-5327534.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Mobile-first web application for fitness tracking and health monitoring.'
    },
    {
      id: 4,
      title: 'Educational Platform Redesign',
      category: 'education',
      image: 'https://images.pexels.com/photos/4145153/pexels-photo-4145153.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Complete UX/UI overhaul for an online learning platform, improving engagement by 65%.'
    },
    {
      id: 5,
      title: 'Luxury Real Estate Website',
      category: 'real-estate',
      image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Premium property listing website with virtual tours and lead generation systems.'
    },
    {
      id: 6,
      title: 'Restaurant Booking System',
      category: 'hospitality',
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Integrated reservation system with real-time availability and customer management.'
    }
  ];

  const filters = [
    { id: 'all', label: 'All Projects' },
    { id: 'ecommerce', label: 'E-commerce' },
    { id: 'corporate', label: 'Corporate' },
    { id: 'health', label: 'Health' },
    { id: 'education', label: 'Education' },
    { id: 'real-estate', label: 'Real Estate' },
    { id: 'hospitality', label: 'Hospitality' }
  ];

  const filteredProjects = activeFilter === 'all'
    ? projects
    : projects.filter(project => project.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Our Featured Projects
          </h2>
          <p className="text-xl text-gray-600">
            Explore our portfolio of successful projects delivered with excellence.
          </p>
        </div>

        <div className="flex flex-wrap justify-center mb-12">
          <div className="flex flex-wrap gap-2 md:gap-4 justify-center">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeFilter === filter.id
                    ? 'bg-blue-700 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 group"
            >
              <div className="relative overflow-hidden h-64">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-6 w-full">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-bold text-white">{project.title}</h3>
                      <a
                        href="#"
                        className="p-2 bg-white/20 rounded-full backdrop-blur-sm text-white hover:bg-white/40 transition-colors duration-300"
                      >
                        <ExternalLink className="w-5 h-5" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600">{project.description}</p>
                <div className="mt-4">
                  <span className="inline-block px-3 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                    {filters.find(f => f.id === project.category)?.label || project.category}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-300"
          >
            Discuss Your Project
          </a>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;